﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CALCULADORA_API;
using NUnit.Framework;

namespace TESTE_CALCULADORA
{
    [TestFixture]
    public class TesteAPICalculadora
    {
        [TestCase(26, 7, 33)]
        [TestCase(58, 43, 101)]
        public void TestarSoma(double a, double b, double c)
        {
            CalculadoraAPI obj = new CalculadoraAPI();
            Assert.AreEqual(c, obj.Somar(a, b));
        }
        [TestCase(21, 3, 18)]
        [TestCase(50, 43, 7)]
        public void TestarSubtracao(double a, double b, double c)
        {
            CalculadoraAPI obj = new CalculadoraAPI();
            Assert.AreEqual(c, obj.Subtrair(a, b));
        }
        [TestCase(3,6,18)]
        [TestCase(-3, -3, 9)]
        public void TestarMultiplicacao(double a, double b, double c)
        {
            CalculadoraAPI obj = new CalculadoraAPI();
            Assert.AreEqual(c, obj.Multiplicar(a, b));
        }
        [TestCase(10, 2, 5)]
        [TestCase(36, 12, 3)]
        public void TestarDivisao(double a, double b, double c)
        {
            CalculadoraAPI obj = new CalculadoraAPI();
            Assert.AreEqual(c, obj.Dividir(a, b));
        }
    }
}
