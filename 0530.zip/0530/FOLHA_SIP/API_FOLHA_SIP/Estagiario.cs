﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_FOLHA_SIP
{
    public class Estagiario:IEstagiario
    {
        public long Cod { get; set; }
        public string Nome { get; set; }
        public double SB { get; set; }
        public double SL { get; set; }
        public double Bonus { get; set; }


        public Estagiario(long Cod, string Nome, double SB, double SL, double Bonus)
        {
            this.Cod = Cod;
            this.Nome = Nome;
            this.SB = SB;
            this.SL = SL;
            this.Bonus = Bonus;
        }

        public Estagiario():this(0, "", 0f, 0f, 100)
        {
                
        }

        public void Imprimir()
        {
            Console.WriteLine("Holerite funcionario ativo");
            Folha();
        }


        public void Ponto(double Horas, double SH)
        {
            if (Horas > 80) Horas = 80;
            SB = Horas * SH;
            if (SB > 606) SB = 606;
        }

        public void Calcular()
        {
            double descontos = 0;
            Console.WriteLine("INSS: {0:C2}", 0);
            Console.WriteLine("IRRF: {0:C2}", 0);
            Console.WriteLine("Bonus: {0:C2}", Bonus);
            SL = SB + Bonus;
            Console.WriteLine("Descontos:{0:C2}", descontos);
        }

        public void Folha()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("COD:{0}\tNome:{1}", Cod, Nome);
            Console.WriteLine("SAlario Bruto:{0:C2}", SB);
            Calcular();
            Console.WriteLine("Salario Liquido: {0:C2}", SL);
            Console.WriteLine("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            Console.WriteLine("");
        }
    }
}
