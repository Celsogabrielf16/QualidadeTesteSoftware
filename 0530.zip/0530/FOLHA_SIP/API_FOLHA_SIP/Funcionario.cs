﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_FOLHA_SIP
{
    public class Funcionario:IFuncionario
    {
        public long Cod { get; set; }
        public string Nome { get; set; }
        public double SB { get; set; }
        public double SL { get; set; }

        public Funcionario(long Cod, string Nome, double SB, double SL)
        {
            this.Cod = Cod;
            this.Nome = Nome;
            this.SB = SB;
            this.SL = SL;
        }

        public Funcionario()
            : this(0, "", 0f, 0f)
        {

        }

        public double Inss()
        {
            if (SB < 1830.29) return SB * 0.08;
            else if (SB >= 1830.29 && SB < 3050.52) return SB * 0.09;
            else return SB * 0.11;

        }

        public double IRRF()
        {
            if (SB < 1903.98) return 0;
            else if (SB >= 1903.98 && SB < 2826.65) return SB * 0.075;
            else if (SB >= 2826.65 && SB < 3751.05) return SB * 0.15;
            else if (SB >= 3751.05 && SB < 4664.68) return SB * 0.225;
            else return SB * 0.27;
        }

        public void Calcular()
        {
            double descontos = Inss();
            Console.WriteLine("INSS: {0:C2}", descontos);
            double IR = IRRF();
            Console.WriteLine("IRRF: {0:C2}", IR);
            descontos += IR;
            SL = SB - descontos;
            Console.WriteLine("Descontos:{0:C2}", descontos);
        }

        public void Folha()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("COD:{0}\tNome:{1}", Cod, Nome);
            Console.WriteLine("SAlario Bruto:{0:C2}", SB);
            Calcular();
            Console.WriteLine("Salario Liquido: {0:C2}", SL);

            Console.WriteLine("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            Console.WriteLine("");
        }

        public void Imprimir()
        {
            Console.WriteLine("Holerite funcionario ativo");
            Folha();
        }

        public void Ponto(double Horas, double SH)
        {
            SB = Horas * SH;
        }
    }
}
