﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_FOLHA_SIP;
using System.Threading;

namespace TESTE_FOLHA
{
    class Program
    {
        static IRH Empresa;

        static void Main(string[] args)
        {
            Empresa = new RH();

            Empresa.Adicionar(new Funcionario(1, "João", 0, 0));
            Empresa.Adicionar(new Funcionario(2, "Gustavão", 0, 0));

            Empresa.Adicionar(new Estagiario(3, "Jorge", 0, 0, 200));

            Empresa.Imprimir();

            Console.CursorTop = 0;
            Console.ReadKey();
        }
    }
}
