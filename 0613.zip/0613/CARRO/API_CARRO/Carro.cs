﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_CARRO
{
    public class Carro:ICarro
    {
        public void ligar()
        {
            Console.WriteLine("Ligando o carro...");
        }

        public void acelerar()
        {
            Console.WriteLine("Acelerando o carro...");
        }
    }
}
