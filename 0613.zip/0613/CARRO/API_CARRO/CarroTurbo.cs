﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_CARRO
{
    public class CarroTurbo:ICarroTurbo
    {
        public void ligar()
        {
            Console.WriteLine("Ligando o carro turbo...");
        }

        public void acelerar()
        {
            Console.WriteLine("Acelerando o carro turbo...");
        }

        public void Turbo()
        {
            Console.WriteLine("Ligando o turbo do carro...");
        }
    }
}
