﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_CARRO;

namespace TESTE_CARRO
{
    class Program
    {
        static ICarro carro;
        static ICarroTurbo carro2;

        static void Main(string[] args)
        {
            carro = new Carro();
            carro2 = new CarroTurbo();

            carro.ligar();
            carro.acelerar();

            carro2.ligar();
            carro2.acelerar();
            carro2.Turbo();
           
            Console.ReadKey();
        }
    }
}
