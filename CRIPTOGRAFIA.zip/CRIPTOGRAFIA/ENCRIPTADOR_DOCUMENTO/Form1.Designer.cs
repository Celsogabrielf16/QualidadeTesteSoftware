﻿namespace ENCRIPTADOR_DOCUMENTO
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAbrir = new System.Windows.Forms.Button();
            this.lbCaminho = new System.Windows.Forms.Label();
            this.btnCodificar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDecodificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAbrir
            // 
            this.btnAbrir.Location = new System.Drawing.Point(12, 89);
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(394, 47);
            this.btnAbrir.TabIndex = 0;
            this.btnAbrir.Text = "ABRIR DOCUMENTO";
            this.btnAbrir.UseVisualStyleBackColor = true;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // lbCaminho
            // 
            this.lbCaminho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCaminho.Location = new System.Drawing.Point(12, 39);
            this.lbCaminho.Name = "lbCaminho";
            this.lbCaminho.Size = new System.Drawing.Size(394, 47);
            this.lbCaminho.TabIndex = 1;
            this.lbCaminho.Text = "LOCAL";
            this.lbCaminho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCodificar
            // 
            this.btnCodificar.Location = new System.Drawing.Point(12, 142);
            this.btnCodificar.Name = "btnCodificar";
            this.btnCodificar.Size = new System.Drawing.Size(394, 47);
            this.btnCodificar.TabIndex = 2;
            this.btnCodificar.Text = "CIDIFICAR";
            this.btnCodificar.UseVisualStyleBackColor = true;
            this.btnCodificar.Click += new System.EventHandler(this.btnCodificar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(15, 248);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(394, 47);
            this.btnSair.TabIndex = 3;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Textos | *.txt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "CAMINHO:";
            // 
            // btnDecodificar
            // 
            this.btnDecodificar.Location = new System.Drawing.Point(15, 195);
            this.btnDecodificar.Name = "btnDecodificar";
            this.btnDecodificar.Size = new System.Drawing.Size(394, 47);
            this.btnDecodificar.TabIndex = 5;
            this.btnDecodificar.Text = "DECODIFICAR";
            this.btnDecodificar.UseVisualStyleBackColor = true;
            this.btnDecodificar.Click += new System.EventHandler(this.btnDecodificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(418, 379);
            this.Controls.Add(this.btnDecodificar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCodificar);
            this.Controls.Add(this.lbCaminho);
            this.Controls.Add(this.btnAbrir);
            this.ForeColor = System.Drawing.Color.Red;
            this.Name = "Form1";
            this.Text = "ENCRIPTADOR DE DOCUMENTROS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAbrir;
        private System.Windows.Forms.Label lbCaminho;
        private System.Windows.Forms.Button btnCodificar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDecodificar;
    }
}

