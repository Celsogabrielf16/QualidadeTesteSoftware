﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRIPTO_API;
using System.IO;

namespace ENCRIPTADOR_DOCUMENTO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            lbCaminho.Text = openFileDialog1.FileName;
        }

        private void btnCodificar_Click(object sender, EventArgs e)
        {
            StreamReader arquivo = new StreamReader(lbCaminho.Text);
            int qtd = File.ReadAllLines(lbCaminho.Text).Count();

            StreamWriter docsaida = new StreamWriter("C:\\saida\\saida.txt");
            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                docsaida.WriteLine(Cripto.Codificar(linha));
            }

            arquivo.Close();
            docsaida.Close();

            MessageBox.Show("Documento codificado com sucesso");
        }

        private void btnDecodificar_Click(object sender, EventArgs e)
        {
            StreamReader arquivo = new StreamReader(lbCaminho.Text);
            int qtd = File.ReadAllLines(lbCaminho.Text).Count();
            StreamWriter docsaida = new StreamWriter("C:\\saida\\saida.txt");
            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                docsaida.WriteLine(Cripto.Decodificar(linha));
            }
            arquivo.Close();
            docsaida.Close();
            MessageBox.Show("Documento decodificado com sucesso");
        }
    }
}
