﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOLHA_PAGAMENTO
{
    public class CalculoSalarioAposentado:ICalculoSalario
    {
        public int CodEmp { get; set; }
        public string Nome { get; set; }

        public CalculoSalarioAposentado(int CodEmp, string Nome)
        {
            this.CodEmp = CodEmp;
            this.Nome = Nome;
        }

        public double Calcular(double SalarioHora)
        {
            double sb = SalarioHora * 160;
            if (sb < 6050) return sb;
            else return 6050;
        }

        public double Imposto(double Valor)
        {
            double Desconto = Valor * 0.005;
            return Desconto;
        }

        public void Imprimir()
        {
            double sb = Calcular(18);
            double desconto = Imposto(sb);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO - APOSENTADO");
            Console.WriteLine("COD: {0}", CodEmp);
            Console.WriteLine("NOME: {0}", Nome);
            Console.WriteLine("SAL BR: {0:c2}", sb);
            Console.WriteLine("DES : {0:c2}", desconto);
            Console.WriteLine("SAL LQ: {0:c2}", sb - desconto);
            Console.WriteLine("----------------------------");
        }
    }
}
