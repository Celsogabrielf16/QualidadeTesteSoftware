﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOLHA_PAGAMENTO
{
    public class CalculoSalarioEstagiario:ICalculoSalario
    {
        public int CodEmp { get; set; }
        public string Nome { get; set; }
        public double Adicional;

        public CalculoSalarioEstagiario(int CodEmp, string Nome, double Adicional)
        {
            this.CodEmp = CodEmp;
            this.Nome = Nome;
            this.Adicional = Adicional;
        }

        public double Calcular(double SalarioHora)
        {
            return (SalarioHora * 0.5 * 80) + Adicional;
        }

        public double Imposto(double Valor)
        {
            return 0;
        }

        public void Imprimir()
        {
            double sb = Calcular(18);
            double desconto = Imposto(sb);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO - ESTAGIARIO ");
            Console.WriteLine("COD: {0}", CodEmp);
            Console.WriteLine("NOME: {0}", Nome);
            Console.WriteLine("SAL BR: {0:c2}", sb);
            Console.WriteLine("DES : {0:c2}", desconto);
            Console.WriteLine("SAL LQ: {0:c2}", sb - desconto);
            Console.WriteLine("----------------------------");
        }
    }
}
