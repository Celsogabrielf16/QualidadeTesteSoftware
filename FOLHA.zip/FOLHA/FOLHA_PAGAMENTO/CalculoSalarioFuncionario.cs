﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOLHA_PAGAMENTO
{
    public class CalculoSalarioFuncionario:ICalculoSalario
    {
        public int CodEmp { get; set; }
        public string Nome { get; set; }
        public double HorasTrabalhadas { get; set; }

        public CalculoSalarioFuncionario(int CodEmp, string Nome, double HorasTrabalhadas)
        {
            this.CodEmp = CodEmp;
            this.Nome = Nome;
            this.HorasTrabalhadas = HorasTrabalhadas;
        }

        public double Calcular(double SalarioHora)
        {
            double sb = HorasTrabalhadas * SalarioHora;
            return sb;
        }

        public double Imposto(double Valor)
        {
            double Desconto = Valor * 0.02;
            return Desconto;
        }

        public void Imprimir()
        {
            double sb = Calcular(18);
            double desconto = Imposto(sb);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO");
            Console.WriteLine("NOME: {0}", Nome);
            Console.WriteLine("SAL BR: {0:c2}", sb);
            Console.WriteLine("DES : {0:c2}", desconto);
            Console.WriteLine("SAL LQ: {0:c2}", sb - desconto);
            Console.WriteLine("----------------------------");
        }
    }
}
