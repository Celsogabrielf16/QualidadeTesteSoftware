﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FOLHA_PAGAMENTO;

namespace FOLHA_TESTAR
{
    class Program
    {
        static List<ICalculoSalario> lista;

        static void Main(string[] args)
        {
            lista = new List<ICalculoSalario>();
            lista.Add(
                new CalculoSalarioFuncionario(
                        1, "JOAO NINGUEM DA SILVA", 160)
                    );
            lista.Add(
                new CalculoSalarioFuncionario(
                        2, "MARIA NINGUEM DA SILVA", 250)
                    );
            lista.Add(
                new CalculoSalarioAposentado(
                        3, "JOAQUIN GG")
                    );
            lista.Add(
                new CalculoSalarioAposentado(
                        4, "JOAQUINA RAMOS")
                    );
            lista.Add(
                new CalculoSalarioEstagiario(
                        3, "Yarainas Tumbão", 200)
                    );
            lista.Add(
                new CalculoSalarioEstagiario(
                        4, "Marcos Tarciso", 300)
                    );
            lista.ForEach(i => i.Imprimir());
            Console.ReadKey();
        }
    }
}
