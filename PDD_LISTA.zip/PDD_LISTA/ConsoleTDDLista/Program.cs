﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_LISTA;

namespace ConsoleTDDLista
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();
            Console.WriteLine("TESTE API LISTA");
            List<double> amostra = new List<double>(){
                1,2,3,4,5,6,7,8,9,10
            };

            TimeSpan tempo = new TimeSpan();
            DateTime inicio = DateTime.Now;

            double resultado = ListaAPI.Somar(amostra);
            bool teste = resultado == 55;
            if (teste) Console.WriteLine("SOMA Success");
            else Console.WriteLine("Somar Fail");
            Console.WriteLine("Obtido: {0} Esperado: {1}", resultado, 55);

            double resultadoMedia = ListaAPI.Media(amostra);
            bool testeMedia = resultadoMedia == 5.5;
            if (testeMedia) Console.WriteLine("MEDIA Success");
            else Console.WriteLine("Media Fail");
            Console.WriteLine("Obtido: {0} Esperado: {1}", resultadoMedia, 5.5);

            DateTime fim = DateTime.Now;
            tempo = fim - inicio;
            double ms = tempo.TotalMilliseconds;

            Console.WriteLine("Tempo: {0} ms", ms);

            Console.ReadKey();
        }
    }
}
