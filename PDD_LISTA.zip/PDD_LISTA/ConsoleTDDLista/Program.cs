﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_LISTA;

namespace ConsoleTDDLista
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();

            Console.WriteLine("TESTE API LISTA");
            List<double> amostra = new List<double>();
            for (int x = 1; x <= 10000; x++)
                amostra.Add(x);

            TimeSpan tempo = new TimeSpan();
            DateTime inicio = DateTime.Now;

            double resultado = ListaAPI.Somar(amostra);
            bool teste = resultado == 50005000;
            if (teste) Console.WriteLine("SOMA Success");
            else Console.WriteLine("Somar Fail");
            Console.WriteLine("Obtido: {0} Esperado: {1}", resultado, 50005000);

            double resultadoMedia = ListaAPI.Media(amostra);
            bool testeMedia = resultadoMedia == 5000.5;
            if (testeMedia) Console.WriteLine("MEDIA Success");
            else Console.WriteLine("Media Fail");
            Console.WriteLine("Obtido: {0} Esperado: {1}", resultadoMedia, 5000.5);

            DateTime fim = DateTime.Now;
            tempo = fim - inicio;
            double ms = tempo.TotalMilliseconds;

            Console.WriteLine("Tempo: {0} ms", ms);

            Console.ReadKey();
        }
    }
}
