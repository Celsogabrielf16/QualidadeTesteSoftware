﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_POLIGONO
{
    public class Poligono
    {
        public double Lado1 { get; set; }
        public double Lado2 { get; set; }
        public double Lado3 { get; set; }

        public Poligono(double Lado1, double Lado2, double Lado3)
        {
            this.Lado1 = Lado1;
            this.Lado2 = Lado2;
            this.Lado3 = Lado3;
        }

        public virtual double Perimetro()
        {
            return Lado1 + Lado2 + Lado3;
        }

        public virtual double Area()
        {
            if (Lado1 == Lado2 && Lado2 == Lado3)
            {
                return Math.Sqrt(3) / 4 * Math.Pow(Lado1, 2);
            }
            else if (Lado1 != Lado2 && Lado2 != Lado3)
            {
                double h = Math.Sqrt(Math.Pow(Lado2, 2) -
                    Math.Pow(Lado3 / 2, 2));
                return (Lado3 * h) / 2;
            }
            else
            {
                double sp = Perimetro() / 2;
                return Math.Sqrt(sp * (sp - Lado1) * (sp - Lado2)
                    * (sp - Lado3));
            }
        }

        public virtual void ImprimirLados()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Lado 1: {0}", Lado1);
            Console.WriteLine("Lado 2: {0}", Lado2);
            Console.WriteLine("Lado 3: {0}", Lado3);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
