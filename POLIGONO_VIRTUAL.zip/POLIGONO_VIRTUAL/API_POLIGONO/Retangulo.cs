﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_POLIGONO
{
    public class Retangulo: Poligono
    {
        public double Lado4 { get; set; }

        public Retangulo(double Lado1, double Lado2, double Lado3, double Lado4):base(Lado1, Lado2, Lado3)
        {
            this.Lado4 = Lado4;
        }

        public override double Perimetro()
        {
            return base.Perimetro() + Lado4;
        }

        public override double Area()
        {
            return Lado1 * Lado2;
        }

        public override void ImprimirLados()
        {
            base.ImprimirLados();
            Console.WriteLine("Lado 4: {0}", Lado4);
        }
    }
}
