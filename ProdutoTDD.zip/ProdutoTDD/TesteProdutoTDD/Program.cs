﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProdutoAPI;

namespace TesteProdutoTDD
{
    class Program
    {
        static void Main(string[] args)
        {
            IProdutoRepositorio Produto =
                new ProdutoRepositorio();
            Produto.cadastrar();
            Produto.ler();
            Console.ReadKey();
        }
    }
}
