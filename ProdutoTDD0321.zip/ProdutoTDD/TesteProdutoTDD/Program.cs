﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProdutoAPI;

namespace TesteProdutoTDD
{
    class Program
    {
        static void Main(string[] args)
        {

            IProdutoRepositorio Produto =
                new ProdutoRepositorio(
                    new Livro(1,
                              "DOM CASMURRO",
                              "RECORD",
                              "MACHADO DE ASSIS",
                              "123456")
                    );

            IProdutoRepositorio Produto2 =
                new ProdutoRepositorio(
                    new DVD(2, 
                            "CIDADAO KANE",
                            "COLUMBIA",
                            "1941",
                            "ORSON WELLS")
                    );

            IProdutoRepositorio Produto3 =
                new ProdutoRepositorio(
                    new DVD(3,
                            "CIDADAO KANE",
                            "COLUMBIA",
                            "1941",
                            "ORSON WELLS")
                    );

            Produto.ler();
            Produto2.ler();
            Produto3.ler();

            Console.ReadKey();
        }
    }
}
