﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdutoAPI
{
    public class CD: Produto
    {
        public string Genero { get; set; }
        public int Lancamento { get; set; }

        public CD(int ID, string Nome, string 
            Fabricante, string Genero, int Lancamento) 
            : base (ID, Nome, Fabricante)
        {
            this.Genero = Genero;
            this.Lancamento = Lancamento;
        }

        public override void Imprimir()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("PRODUTO CD");
            Console.WriteLine("ID: {0}", ID);
            Console.WriteLine("TITULO: {0}", Nome);
            Console.WriteLine("ESTUDIO: {0}", Fabricante);
            Console.WriteLine("GENERO: {0}", Genero);
            Console.WriteLine("LANCAMENTO: {0}", Lancamento);
        }
    }
}
