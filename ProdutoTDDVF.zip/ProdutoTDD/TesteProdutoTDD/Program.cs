﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProdutoAPI;

namespace TesteProdutoTDD
{
    class Program
    {
        static void Main(string[] args)
        {
            IProdutoRepositorio banco =
                new ProdutoRepositorio(
                    new List<Produto>());

            banco.adicionar(
                    new Livro(1,
                              "DOM CASMURRO",
                              "RECORD",
                              "MACHADO DE ASSIS",
                              "123456")
                    );

            banco.adicionar(
                    new DVD(2,
                            "CIDADAO KANE",
                            "COLUMBIA",
                            "1941",
                            "ORSON WELLS")
                    );

            banco.adicionar(
                    new CD(3,
                            "CARMINA BURANA",
                            "DECA",
                            "ERUDITO",
                            1989)
                    );

            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();

            banco.ler();

            Console.ReadKey();
        }
    }
}
